
//change home beluga title on page load
window.addEventListener("load",
  function() {
    document.getElementById("underrated").innerHTML = "The Arctic Whale - The Most Underrated Animal Deserves a Website";
  }, false
);
